﻿Store store = new Store();

EmailService email = new EmailService();
SmsService sms = new SmsService();

// اتصال هندلرها به
// event
store.PurchaseCompleted += email.OnPurchaseCompleted;
store.PurchaseCompleted += sms.OnPurchaseCompleted;
// وقتی متد 
// Buy
// اجرا بشه این دوتا متد هم اجرا می شوند

store.Buy("laptop");



// کلاس زیر اطلاعاتی درباره خرید نگه می دارد و از کلاس پایه 
// EventArgs
// ارث بری میکند
class PurchaseEventArgs : EventArgs
{
    public string ProductName { get; }

    public PurchaseEventArgs(string productName)
    {
        ProductName = productName;
    }
}


class Store
{
    // تعریف
    // event
    // با استفاده از
    // EventHandler<PurchaseEventArgs>
    public event EventHandler<PurchaseEventArgs> PurchaseCompleted;
    // هرکس که بخواهد از خرید باخبر شود باید به این ایونت وصل شود

    public void Buy(string productName)
    {
        Console.WriteLine($"The purchase of '{productName}' was completed successfully.");

        // اگر کسی به ایونت وصل شده باشد, این ایونت رو به صورت زیر اجرا می کنیم
        PurchaseCompleted?.Invoke(this, new PurchaseEventArgs(productName));
    }
}


class EmailService
{
    public void OnPurchaseCompleted(object sender, PurchaseEventArgs e)
    {
        Console.WriteLine($"The email confirming the purchase of '{e.ProductName}' was sent");
    }
}


class SmsService
{
    public void OnPurchaseCompleted(object sender, PurchaseEventArgs e)
    {
        Console.WriteLine($"The SMS confirming the purchase of '{e.ProductName}' was sent");
    }
}


// این برنامه شبیه‌سازی یک فروشگاه ساده است که از مفهوم
// Event
// استفاده می‌کند
// وقتی کاربر یک خرید انجام می‌دهد با متد
// (store.Buy)،
// برنامه یک ایونت به نام
// PurchaseCompleted
// رو صدا می‌زند

// دو سرویس
// (EmailService و SmsService)
// به این ایونت وصل هستند.
// یعنی وقتی خرید انجام شد، این دو سرویس به طور خودکار اجرا می‌شن و پیام‌های تایید خرید رو نمایش می‌دهند
//
// مزیت این روش اینه که قسمت‌های مختلف برنامه مثل خرید، ایمیل، پیامک
// از هم جدا هستن و بدون اینکه بهم وابسته باشن، با استفاده از ایونت با یکدیگر ارتباط برقرار می‌کنند
