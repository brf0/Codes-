﻿Component1 component1 = new Component1();
Component2 component2 = new Component2();
// Mediator
// ساخته می شود و به هر دو کامپوننت معرفی می شود
new ConcreteMediator(component1, component2);

Console.WriteLine("Client triggers operation A.");
component1.DoA();
// عملیات 
// A
// اجرا می شود

Console.WriteLine();

Console.WriteLine("Client triggers operation D.");
component2.DoD();
// عملیات 
// D
// اجرا می شود



// در اینجا یک اینترفیس
// IMediator
// تعریف کردیم که کامپوننت ها وقتی اتفاقی افتاد به این اینترفیس اطلاع بدهند و 
// Mediator
// هم براساس آن اتفاق تصمیم بگیرد که چه عملی انجام دهد
public interface IMediator
{
    void Notify(object sender, string ev);
    // این متد رویداد ها رو به 
    // Mediator
    // اطلاع میده
}

// کلاس زیر 
// Mediator
// اصلی است که مسئول هماهنگی بین کامپوننت ها است و مشخص می کند هر کدام چه زمانی, چه کاری را انجام بدهند
class ConcreteMediator : IMediator
{
    private Component1 _component1;

    private Component2 _component2;

    // constructor
    // زیر کامپوننت ها رو دریافت می کنه و خودش رو به اونها معرفی می کنه تا کامپوننت ها بفهمن که باید از طریق این 
    // Mediator
    // باهم در ارتباط باشند
    public ConcreteMediator(Component1 component1, Component2 component2)
    {
        this._component1 = component1;
        this._component1.SetMediator(this);
        // معرفی 
        // Mediator
        // به کامپوننت اول
        this._component2 = component2;
        this._component2.SetMediator(this);
        // معرفی 
        // Mediator
        // به کامپوننت دوم
    }

    // وقتی کامپوننت ها رویدادی رو اعلام کنند اینجا تصمیم گرفته می شود که چه کاری انجام شود
    public void Notify(object sender, string ev)
    {
        if (ev == "A")
        {
            Console.WriteLine("Mediator reacts on A and triggers following operations:");
            this._component2.DoC();
        }
        // اگر رویداد 
        // A
        // باشد کامپوننت 2 عملیات 
        // DoC
        // را اجرا می کند
        if (ev == "D")
        {
            Console.WriteLine("Mediator reacts on D and triggers following operations:");
            this._component1.DoB();
            this._component2.DoC();
        }
        // اگر رویداد 
        // D
        // باشد کامپوننت 1 عملیات 
        // DoB
        // را اجرا می کند و کامپوننت 2 عملیات 
        // DoC
    }
}

// کلاس زیر یک کلاس پایه برای کامپوننت ها است تا بتوانند یک 
// Mediator
// داشته باشند
class BaseComponent
{
    protected IMediator _mediator;

    // سازنده می تواند 
    // Mediator
    // را دریافت کند یا نکند 
    public BaseComponent(IMediator mediator = null)
    {
        this._mediator = mediator;
    }
    // اگر دریافت نکرد می تونیم بعدا با 
    // SetMediator
    // تنظیمش کنیم

    // متدی برای تنظیم یا تغییر 
    // Mediator
    public void SetMediator(IMediator mediator)
    {
        this._mediator = mediator;
    }
}

// کامپوننت 1 عملیات 
// A & B
// را انجام می دهد
class Component1 : BaseComponent
{
    public void DoA()
    {
        Console.WriteLine("Component 1 does A.");

        this._mediator.Notify(this, "A");
        // وقتی عملیات 
        // A
        // انجام شد به 
        // Mediator
        // اطلاع می دهد
    }

    public void DoB()
    {
        Console.WriteLine("Component 1 does B.");

        this._mediator.Notify(this, "B");
    }
    // وقتی عملیات 
    // B
    // انجام شد به 
    // Mediator
    // اطلاع می دهد
}

// کامپوننت 2 عملیات 
// C & D
// را انجام می دهد
class Component2 : BaseComponent
{
    public void DoC()
    {
        Console.WriteLine("Component 2 does C.");

        this._mediator.Notify(this, "C");
    }
    // وقتی عملیات 
    // C
    // انجام شد به 
    // Mediator
    // اطلاع می دهد

    public void DoD()
    {
        Console.WriteLine("Component 2 does D.");

        this._mediator.Notify(this, "D");
    }
    // وقتی عملیات 
    // D
    // انجام شد به 
    // Mediator
    // اطلاع می دهد
}

// این برنامه پیاده‌سازی الگوی 
// Mediator
// است که ارتباط بین کامپوننت‌ها را مدیریت می کند
// کامپوننت‌ها به جای اینکه مستقیما با یکدیگر در ارتباط باشند از طریق کلاس 
// ConcreteMediator
// با یکدیگر هماهنگ می‌شوند. کلاس 
// ConcreteMediator
// تصمیم می گیرد که وقتی یک کامپوننت کاری انجام داد بقیه چه واکنشی نشان دهند
// این کار باعث می شود که وابستگی بین کلاس ها کم شود و مدیریت رفتارها راحت تر شود
