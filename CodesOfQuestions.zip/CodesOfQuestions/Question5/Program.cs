﻿// اول یک شی از 
// Adaptee
// و بعد هم یک شی از
// Adapter 
// می سازیم و 
// adaptee
// رو بهش میدیم
Adaptee adaptee = new Adaptee();
ITarget target = new Adapter(adaptee);

Console.WriteLine("Adaptee interface is incompatible with the client.");
Console.WriteLine("But with adapter client can call it's method.");

// و در اینجا متدی که کلاینت می خواست رو صدا می زنیم
Console.WriteLine(target.GetRequest());
// خروجی کد بالا:
// This is 'Specific request.'



// Target
// اینترفیسی است که توسط کد 
// client
// استفاده میشه
public interface ITarget
{
    string GetRequest();
    // متدی که 
    // client
    // قراره صدا بزنه
}


// در کلاس زیر یک متد تعریف شده که اسم و شکلش با چیزی که کلاینت می خواد فرق داره
class Adaptee
{
    public string GetSpecificRequest()
    {
        return "Specific request.";
    }
    // این متد فقط در کلاس 
    // Adaptee
    // هست
}


// کلاس زیر به عنوان یه واسط بین
// ITarget & Adaptee
// عمل میکنه. و کمک می کنه که کلاینت بتونه از 
// Adaptee
// استفاده کنه
class Adapter : ITarget
// چون کلاینت با اینترفیس 
// ITarget
// کار میکنه, باید در کلاس 
// Adapter
// این اینترفیس رو پیاده سازی کنیم
{
    private readonly Adaptee _adaptee;
    // یک شی از 
    // Adaptee
    // نگه می داریم و توی 
    // constructor
    // مقداردهی اش میکنیم

    public Adapter(Adaptee adaptee)
    {
        this._adaptee = adaptee;
    }

    // متد زیر متدی هست که کلاینت صدا میزنه
    // و ما داخل این متد, متد
    // Adaptee
    // رو صدا می زنیم و به شکل دلخواه کلاینت نشونش می دیم
    public string GetRequest()
    {
        return $"This is '{this._adaptee.GetSpecificRequest()}'";
    }
}


// این برنامه از الگوی
// Adapter
// استفاده می‌کند تا دو کلاس با رابط ها ناسازگار را به هم وصل کند
// کلاس
// Adaptee
// متدی دارد که اسم یا ساختارش با نیاز برنامه فرق دارد، اما اطلاعات مفیدی فراهم می‌کند
// کلاس
// Adapter
// نقش واسطه را دارد و متدهای
// Adaptee
// را طوری تبدیل می‌کند که برای برنامه قابل استفاده باشد
// Client
// فقط با اینترفیس
// Target
// کار می‌کند و نیازی نیست که ساختار داخلی
// Adaptee
// را بشناسد
// این الگو زمانی مفید است که بخواهیم از یک کلاس قدیمی یا ناسازگار در برنامه‌ای جدید استفاده کنیم