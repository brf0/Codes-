﻿// Singleton Design Pattern

MyClass obj1 = MyClass.CreateInstance();
MyClass obj2 = MyClass.CreateInstance();
MyClass obj3 = MyClass.CreateInstance();

obj1.x = 4;

Console.WriteLine(obj1.x);
Console.WriteLine(obj2.x);
Console.WriteLine(obj3.x);
// 4
// 4
// 4

class MyClass
{
    // کد زیر از الگوی
    // Singleton
    // در زبان سی شارپ استفاده می‌کند. این الگو تضمین می‌کند که فقط یک نمونه از کلاس ساخته شود و همهٔ ارجاعات به همان نمونه اشاره کنند

    private static MyClass? instance;
    // instance
    // یک متغیر استاتیک از نوع
    // MyClass
    // هست که در سطح کلاس تعریف شده و فقط یک نمونه از آن می تواند ایجاد شود

    public int x { get; set; }
    // یک پراپرتی تعریف شده در کلاس است

    private MyClass() { }
    // یک سازنده خصوصی است که خارج از کلاس نمی توان نمونه‌ای از آن ایجاد کرد.
    // این کار باعث می‌شود فقط از طریق متد
    // CreateInstance
    // بتوان نمونه‌ای از کلاس را گرفت

    public static MyClass CreateInstance()
    {
        if (instance is null) { instance = new MyClass(); }

        return instance;
        // در اینجا اگر مقدار
        // null
        // باشد، یک نمونه جدید از
        // MyClass
        // ایجاد شده و در
        // instance
        // ذخیره می‌شود.
        // در غیر این صورت، مقدار موجود در
        // instance
        // بازگردانده می شود

        // این مکانیزم باعث می‌شود که همیشه فقط یک
        // instance
        // از کلاس
        // MyClass
        // وجود داشته باشد.
    }
}